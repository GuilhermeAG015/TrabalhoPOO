package banco;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Principal {
	public static void main(String[] args) {
		ArrayList<Conta> contas = new ArrayList<Conta>();
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();

		Conta conta;
		Cliente cliente;

		Scanner scanner = new Scanner(System.in);
		int opc = 0;
		int idCliente = 0;
		int idConta = 0;
		do {
			System.out.println("-------------------------------");
			System.out.println("1 - Adicionar um cliente");
			System.out.println("2 - Criar uma conta");
			System.out.println("3 - Consultar saldo");
			System.out.println("4 - Sacar");
			System.out.println("5 - Depositar");
			System.out.println("0 - Sair");
			System.out.println("-------------------------------");
			System.out.println("Escolha uma op��o:");

			opc = Integer.parseInt(scanner.nextLine());

			switch (opc) {

			case 1:
				// ADICIONA UM CLIENTE
				System.out.println("Digite o nome do cliente");
				String nomeCliente = scanner.nextLine();
				idCliente = idCliente + 1;
				cliente = new Cliente(idCliente, nomeCliente);
				clientes.add(cliente);
				System.out.println("-------------------------------");
				break;

			case 2:
				// CRIA UMA NOVA CONTA
				System.out.println("Escolha o cliente da conta");
				for (Cliente c : clientes) {
					System.out.println(c.getIdCliente() + " - " + c.getNomeCliente());
				}
				int id = Integer.parseInt(scanner.nextLine());
				System.out.println("Digite  tipo da conta");
				String tipoConta = scanner.nextLine();
				System.out.println("Digite o saldo da conta");
				Double saldo = Double.parseDouble(scanner.nextLine());
				idConta = idConta + 1;
				conta = new Conta(idConta, (clientes.get(id - 1)), tipoConta, saldo);
				contas.add(conta);
				System.out.println("-------------------------------");
				break;

			case 3:
				// CONSULTA O SALDO DA CONTA
				System.out.println("Escolha a conta");
				for (Conta c : contas) {
					System.out.println(c.getIdConta() + " " + c.getCliente().getNomeCliente());
				}
				int idContaSaldo = Integer.parseInt(scanner.nextLine());
				System.out.println("Seu saldo � de: " + contas.get(idContaSaldo - 1).getSaldo());
				System.out.println("-------------------------------");
				break;

			case 4:
				// SACAR
				System.out.println("Escolha a conta");
				for (Conta c : contas) {
					System.out.println(c.getIdConta() + " " + c.getCliente().getNomeCliente());
				}
				int idContaSaque = Integer.parseInt(scanner.nextLine());
				System.out.println("Digite o valor do saque");
				Double valorSaque = Double.parseDouble(scanner.nextLine());
				contas.get(idContaSaque - 1).sacar(valorSaque);
				System.out.println("-------------------------------");
				break;

			case 5:
				// DEPOSITAR
				System.out.println("Escolha a conta");
				for (Conta c : contas) {
					System.out.println(c.getIdConta() + " " + c.getCliente().getNomeCliente());
				}
				int idContaDeposito = Integer.parseInt(scanner.nextLine());
				System.out.println("Digite o valor do deposito");
				Double valorDeposito = Double.parseDouble(scanner.nextLine());
				contas.get(idContaDeposito - 1).depositar(valorDeposito);
				System.out.println("-------------------------------");

				break;
				
			case 0:
				System.out.println("Sess�o encerrada");

			default:
				System.out.println("Op��o invalida");
				System.out.println("-------------------------------");
				break;
			}
		} while (opc != 0);

	}
}
package banco;

public class Conta {
	private int idConta;
	private Cliente cliente;
	private String tipo;
	private Double saldo;
	
	public Conta(int idConta, Cliente cliente, String tipo, Double saldo) {
		super();
		this.idConta = idConta;
		this.cliente = cliente;
		this.tipo = tipo;
		this.saldo = saldo;
	}

	public int getIdConta() {
		return idConta;
	}

	public void setIdConta(int idConta) {
		this.idConta = idConta;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Double getSaldo() {
		return saldo;
	}

	public void depositar(Double valorDeposito) {
		if(valorDeposito > 0) {
			this.saldo += valorDeposito;
			System.out.println("Deposito feito com sucesso na conta do " + getCliente().getNomeCliente());
		}else {
			System.out.println("Valor invalido! N�o foi possivel depositar na conta do " + getCliente().getNomeCliente());
		}
		
	}
	
	public void sacar(Double valorSaque) {
		if(valorSaque > this.saldo || valorSaque < 0) {
			System.out.println("Valor invalido!!");
		}else{
			this.saldo -= valorSaque;
			System.out.println("Saque feito com sucesso da conta do " + getCliente().getNomeCliente());
		}
	}
}
